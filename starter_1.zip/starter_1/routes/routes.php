<?php

return $routes = [
    '/' => 'index.php',
    '/login' => 'login.php',
    '/register' => 'register.php',
    '/forgetpwd' => 'forgetpwd.php',
    
];
