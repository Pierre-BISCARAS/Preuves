<?php
// Ajout d'un utilisateur à la base de données
function addUser($firstname,$lastname,$email,$pwd) {
    $pdo = getPdo();
    $pdo->prepare("INSERT INTO info (firstname,lastname,email,password,role) values ('$firstname','$lastname','$email','$pwd','membre');")->execute();
}

// Renvoit de l'email
function findEmail($email) {
    $pdo = getPdo();
    $resultat = $pdo->query("select password from info where email like '$email';")->fetch(PDO::FETCH_ASSOC);
    return $resultat[0]['password'];
}

function verifmail($email) {
    $pdo = getPdo();

    $resultat = $pdo->query("SELECT * FROM info WHERE email='$email';")->fetch(PDO::FETCH_ASSOC);
    if (empty($resultat)) {
        return TRUE;
    }
    else {
        return FALSE;

    }
}

function envoiMail($email,$name,$object,$message) {
    $mail = new PHPMailer(true);

    try{
        $mail->SMTPDebug = 0;
        $mail->isSMTP();
        $mail->Host = '127.0.0.1';   
        // Autorise le cryptage TLS
        $mail->SPTMSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 1025; // 587
        // destinataire
        $mail->setFrom($email);
        // Ajout d'un destinataire
        $mail->addAddress($email,$name);
        // Met le mail en HTML
        $mail->isHTML(true);
        //Contenu de mail
        $mail->Subject = $object;
        $mail->Body = $message;
        // Envoi du mail
        $mail->send();
    }catch(Exception $e){
        echo "Message could not be sent, Mailer error: {$mail->ErrorInfo}";
    }
}




