<h1>Salut <?=$name?></h1>

<form action="" method="POST">
    <input type="mail" name="email" placeholder = "email" required="required">
    <input type="password" name="password" placeholder = "password" required="required">
    <input type="submit" value="Envoyer">
    <a href='/forgetpwd'>mots de passe</a>

</form>
