

<h1> Bonjour <?=$name?></h1>

<form action="" method ="POST">
    <input type="text" name="firstname">
    <input type="text" name="lastname">
    <input type="submit" value="Envoyer">
    <input type="submit" name="destroy" value="deconnexion">
</form>