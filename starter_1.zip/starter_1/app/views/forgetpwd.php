

<input type="text" name="firstname" placeholder="Prenom">
<input type="mail" name="email" placeholder = "email">
<input type="submit" name="envoyer "value="Envoyer">
