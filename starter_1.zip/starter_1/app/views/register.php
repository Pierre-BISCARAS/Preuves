
<h1> Bonjour <?=$name?></h1>

<form action="" method="POST">
    <input type="text" name="firstname" placeholder="Prenom">
    <input type="text" name="lastname" placeholder="nom">
    <input type="mail" name="email" placeholder = "email">
    <input type="password" name="password" placeholder = "password">
    <input type="password" name="confirmYourPassword" placeholder = "Confirm your password">
    <input type="submit" value="Envoyer">
</form>
