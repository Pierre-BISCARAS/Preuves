<?php

function view(string $routeName, array $data = []): void
{
    extract($data, EXTR_SKIP);
    require  __DIR__."/../views/$routeName.php";
}

function getPdo()
{

    $databaseName = 'phptp3';
    // $username = 'lilian';
    // $password = 'Lilian1003';

    $host = 'localhost';
    $username = 'pierre';
    $password = 'necPA459';
    try  {
    $pdo = new PDO("pgsql:host=$host;port=5432;dbname=$databaseName;user=$username;password=$password");
    $pdo ->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
    catch(Exception $e) {
        die ('Erreur :' .$e->getMessage());
    }
        // 
        return $pdo;
}

function getConfig() :array
{
    return [

    ];
}
