<?php

function view(string $routeName, array $data = []): void
{
    extract($data, EXTR_SKIP);
    require  __DIR__."/../views/$routeName.php";
}

function getPdo()
{

    $databaseName = 'phptp3';
    // $username = ' ';
    // $password = ' ';

    $host = 'localhost';
    $username = ' ';
    $password = ' ';
    try  {
    $pdo = new PDO("pgsql:host=$host;port=5432;dbname=$databaseName;user=$username;password=$password");
    $pdo ->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    }
    catch(Exception $e) {
        die ('Erreur :' .$e->getMessage());
    }
        // 
        return $pdo;
}

function getConfig() :array
{
    return [

    ];
}
