<?php

// Utilisation de user.php
require __DIR__."/../models/user.php";


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';


$name = $_POST["name"];
$email = $_POST["email"];
$password = $_POST["password"];


// Récupération du mdp
$password = $_POST['password'];
$passwordConfirm = $_POST['confirmYourPassword'];
$email = $_POST["email"];
$password_regex = "/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{12,}$/"; 
// Cryptage du mdp
$passwordConfirmhash = password_hash($passwordConfirm, PASSWORD_BCRYPT);


$name = 'test';
// Vérification 
if (preg_match($password_regex, $password)) {
    if (password_verify($password, $passwordConfirmhash)) {
        if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
            if (verifmail($email)) {
                addUser($_POST["firstname"],$_POST["lastname"],$email,$passwordConfirmhash);
                envoiMail($email,$name,'Email verification','<p>Your verification code is : <b style="font-size: 30px;">');
                $name = 'Password is valid!';
                header('location: /');
            }
            else{
                $name ="email is already registered";
            }
        }
        else {
            $name = 'Invalid email';
        }
    }
    else {
        $name =  'les mdp sont différents';

    }
}
 else {
    $name = "Invalid password : Le password doit comporter minimun 12 caractères avec minimun 1 majuscule, minimun 1 chiffre, minimun 1 caractère spécial.";

 }


    
view('register',[
    'name' => $name,

]);