<?php

require __DIR__."/../models/user.php";

// PAGE DE CONNEXION
$name = "lilian";

// Vérification du mdp

// Récupération du mdp entré
$pwd = $_REQUEST["password"];
$email = $_POST["email"];
// Cryptage du mdp
$hash = password_hash($pwd,PASSWORD_BCRYPT);    
// On vérifie si c'est le bon mdp
if(password_verify($pwd,findEmail($email))){
    if (!(empty($email)) and !(empty($pwd))) {
        header('location: /');
    }

    echo 'Correct';
    }
    else{
    echo 'Incorrect';
};

view('login',[
    'name' => $name
]);
