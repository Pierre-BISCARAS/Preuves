<?php


$_SESSION= array();
var_dump($_SESSION);
if(!empty($_POST['destroy'])) {
    $name = $_POST['destroy'];
    session_destroy();
    header('location: /login');
    
    
 }

view('index',[
    'name' => $name
]);
