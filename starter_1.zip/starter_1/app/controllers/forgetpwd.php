<?php

$email = $_POST['email'];
$name = $_POST['firstname'];

$message = 'test';
if (!empty($_POST['envoyer'])) {
    
    envoiMail($email,$name,'Password forget',"test");
}

view('forgetpwd',[

]);